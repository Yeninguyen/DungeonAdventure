package Model;

public class Hero {
}
