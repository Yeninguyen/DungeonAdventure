package Model;

public class Monster {
}
