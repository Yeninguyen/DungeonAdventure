package Model;

public class Adventurer {
}
