package Model;

public class Thief {
}
