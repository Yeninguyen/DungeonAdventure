package View;

public class CharacterView {
}
