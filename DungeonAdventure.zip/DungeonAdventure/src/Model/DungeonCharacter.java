package Model;

public class DungeonCharacter {
}
