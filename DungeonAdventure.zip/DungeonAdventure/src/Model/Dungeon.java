package Model;

public class Dungeon {
}
