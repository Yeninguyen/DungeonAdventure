package Model;

public class Priestess {
}
