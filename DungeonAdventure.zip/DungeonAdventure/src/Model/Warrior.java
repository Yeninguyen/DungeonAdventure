package Model;

public class Warrior {
}
