package Model;

public class Room {
}
